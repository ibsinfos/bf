<?php
require_once('class_order.php');
require_once('class_paypal.php');
require_once('class_cash.php');
require_once('functions.php');