<?php if ( is_active_sidebar( 'main' ) ) : ?>
		<?php dynamic_sidebar( 'main' ); ?>
<?php endif; ?>
