<?php if ( is_active_sidebar( 'blog' ) ) : ?>
		<?php dynamic_sidebar( 'blog' ); ?>
<?php endif; ?>
